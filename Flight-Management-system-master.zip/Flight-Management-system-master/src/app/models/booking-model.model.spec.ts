import { BookingModel } from './booking-model.model';

describe('BookingModel', () => {
  it('should create an instance', () => {
    expect(new BookingModel()).toBeTruthy();
  });
});
