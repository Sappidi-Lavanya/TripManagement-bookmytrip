import { Cancel } from './cancel.model';

describe('Cancel', () => {
  it('should create an instance', () => {
    expect(new Cancel()).toBeTruthy();
  });
});
