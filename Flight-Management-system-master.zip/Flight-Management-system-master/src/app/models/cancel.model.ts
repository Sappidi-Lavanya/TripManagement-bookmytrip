export class Cancel {
    constructor(
         public booking_cancelled:boolean
    ){}
}
