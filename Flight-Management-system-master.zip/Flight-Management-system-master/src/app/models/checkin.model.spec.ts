import { Checkin } from './checkin.model';

describe('Checkin', () => {
  it('should create an instance', () => {
    expect(new Checkin()).toBeTruthy();
  });
});
