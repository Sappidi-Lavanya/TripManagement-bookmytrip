export class Checkin {
booking_id?:any;
checked_in?:boolean;
}

