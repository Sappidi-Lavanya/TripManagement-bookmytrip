import { FlightModel } from './flight-model.model';

describe('FlightModel', () => {
  it('should create an instance', () => {
    expect(new FlightModel()).toBeTruthy();
  });
});
