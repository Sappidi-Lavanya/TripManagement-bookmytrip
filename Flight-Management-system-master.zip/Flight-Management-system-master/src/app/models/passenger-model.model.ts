export class PassengerModel {
    constructor(
         public passenger_id:number,
         public passenger_name:string,
         public passenger_age:number,
         public passenger_seat:number,
         public amount:number
         )
        
         {    
        }
}
